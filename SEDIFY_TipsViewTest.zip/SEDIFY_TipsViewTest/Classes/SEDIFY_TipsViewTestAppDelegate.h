//
//  SEDIFY_TipsViewTestAppDelegate.h
//  SEDIFY_TipsViewTest
//
//  Created by Steve Milano on 11/29/10.
//  Copyright 2010 by SEDIFY. All rights reserved.
//

#import <UIKit/UIKit.h>

@class SEDIFY_TipsViewTestViewController;

@interface SEDIFY_TipsViewTestAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    SEDIFY_TipsViewTestViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet SEDIFY_TipsViewTestViewController *viewController;

@end

