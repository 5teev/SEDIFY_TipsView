//
//  SEDIFY_TipsViewTestViewController.h
//  SEDIFY_TipsViewTest
//
//  Created by Steve Milano on 11/29/10.
//  Copyright 2010 by SEDIFY. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SEDIFY_TipsView.h"

@interface SEDIFY_TipsViewTestViewController : UIViewController <SEDIFY_TipsViewDelegate> {
	IBOutlet SEDIFY_TipsView * tv;
}

@end

