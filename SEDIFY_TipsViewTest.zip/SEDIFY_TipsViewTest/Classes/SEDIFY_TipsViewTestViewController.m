//
//  SEDIFY_TipsViewTestViewController.m
//  SEDIFY_TipsViewTest
//
//  Created by Steve Milano on 11/29/10.
//  Copyright 2010 by SEDIFY. All rights reserved.
//

#import "SEDIFY_TipsViewTestViewController.h"

@implementation SEDIFY_TipsViewTestViewController



/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/* */
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
	tv = [[SEDIFY_TipsView alloc] initWithFrame:[[UIScreen mainScreen] bounds]];// self.view.frame
	[self.view addSubview:tv];
	tv.delegate = self;
    [super viewDidLoad];
}
/* */

- (void)tipsViewDidFinish:(SEDIFY_TipsView *)view
{
	[view release];
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}

@end
